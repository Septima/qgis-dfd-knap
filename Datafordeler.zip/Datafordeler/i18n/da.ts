<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>@default</name>
    <message>
        <location filename="test_translations.py" line="48"/>
        <source>Good morning</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Dialog</name>
    <message>
        <location filename="aboutKortforsyningenAlternative.ui" line="22"/>
        <source>About the plugin</source>
        <translation>Om dette plugin</translation>
    </message>
</context>
<context>
    <name>KfConfig</name>
    <message>
        <location filename="kf_config.py" line="158"/>
        <source>No contact to Kortforsyningen</source>
        <translation>Ingen kontakt til Kortforsyningen</translation>
    </message>
</context>
<context>
    <name>Kortforsyningen</name>
    <message>
        <location filename="kortforsyningen.py" line="194"/>
        <source>Kortforsyningen</source>
        <translation>Kortforsyningen</translation>
    </message>
    <message>
        <location filename="kortforsyningen.py" line="244"/>
        <source>Settings</source>
        <translation>Indstillinger</translation>
    </message>
    <message>
        <location filename="kortforsyningen.py" line="254"/>
        <source>About the plugin</source>
        <translation>Om dette plugin</translation>
    </message>
    <message>
        <location filename="kortforsyningen.py" line="148"/>
        <source>No contact to Kortforsyning</source>
        <translation>Ingen kontakt til Kortforsyningen</translation>
    </message>
    <message>
        <location filename="kortforsyningen.py" line="170"/>
        <source>Username/Password not set or wrong. Click menu Settings-&gt;Options-&gt;Kortforsyningen</source>
        <translation>Brugernavn/kodeord er ikke indtastet eller er forkert. Klik på Indstillinger-&gt;Generelle indstillinger-&gt;Kortforsyningen</translation>
    </message>
    <message>
        <location filename="kortforsyningen.py" line="336"/>
        <source>&lt;p&gt;QGIS is having trouble showing the content of this dialog. Would you like to open it in an external browser window?&lt;/p&gt;</source>
        <translation>&lt;p&gt;QGIS har problemer med at vise indholdet af denne dialogboks. Ønsker du at vise det i et eksternt browservindue?&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>s</name>
    <message>
        <location filename="kf_settings.ui" line="50"/>
        <source>Username</source>
        <translation>Brugernavn</translation>
    </message>
    <message>
        <location filename="kf_settings.ui" line="60"/>
        <source>Password</source>
        <translation>Kodeord</translation>
    </message>
    <message>
        <location filename="kf_settings.ui" line="14"/>
        <source>Kortforsyningen - Settings</source>
        <translation>Kortforsyningen - Indstillinger</translation>
    </message>
    <message>
        <location filename="kf_settings.ui" line="44"/>
        <source>Userinformation to Kortforsyningen</source>
        <translation>Brugerinformation til Kortforsyningen</translation>
    </message>
    <message>
        <location filename="kf_settings.ui" line="80"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Not registered as user at Kortforsyningen? &lt;a href=&quot;http://download.kortforsyningen.dk//content/opret-mig-som-bruger&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Create user&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ikke registreret som bruger på Kortforsyningen? &lt;a href=&quot;http://download.kortforsyningen.dk//content/opret-mig-som-bruger&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Opret bruger&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="kf_settings.ui" line="93"/>
        <source>Extend Kortforsyningsplugin with qlr-file</source>
        <translation>Udvid Kortforsyningsplugin med qlr-fil</translation>
    </message>
    <message>
        <location filename="kf_settings.ui" line="124"/>
        <source>Open qlr-file</source>
        <translation>Åben qlr-fil</translation>
    </message>
    <message>
        <location filename="kf_settings.ui" line="134"/>
        <source>Only display backgroundmap from Kortforsyningen</source>
        <translation>Vis kun baggrundskort fra Kortforsyningen</translation>
    </message>
    <message>
        <location filename="kf_settings.ui" line="156"/>
        <source>Save settings</source>
        <translation>Gem indstillinger</translation>
    </message>
</context>
</TS>
